const baseUrl = 'http://localhost:19001';

export default baseUrl;