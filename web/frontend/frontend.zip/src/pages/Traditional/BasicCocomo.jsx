import React, { useState } from 'react';

function BasicCocomo() {

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
        <header>
        <h1>Cocomo I</h1>
       
      </header>
      <h2>COCOMO I</h2>
      
      <div>
        <label>Enter KLOC:</label>
      </div>
      
      
      
      <p>Total LOC:</p>
      
      
    </div>
  );
}

export default BasicCocomo;
