export default {
    primary: '#f57c00',
    gray: '#C5C5C7',
    mediumGray: '#F6F7FB',
    lightGray: '#FAFAFA'
};
